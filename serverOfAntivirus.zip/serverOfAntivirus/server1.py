from http.server import HTTPServer, BaseHTTPRequestHandler
from malware_check import  checkMalware
hostName = "192.168.1.69"
hostPort = 8000

class Serv(BaseHTTPRequestHandler):

    def do_GET(self):
        self.send_response(200)
        self.end_headers()
        if self.path=='/check':
            self.wfile.write(bytes("test", 'utf-8'))

    def do_POST(self):
        self.send_response(200)
        self.end_headers()
        content_length=int(self.headers['Content-Length'])
        #print('content_length ',content_length)
        post_data = self.rfile.read(content_length)
        post_data=post_data.decode('utf-8')

        state=checkMalware(post_data)
        print(state)
        self.wfile.write(bytes(state, 'utf-8'))



httpd = HTTPServer((hostName, hostPort), Serv)
httpd.serve_forever()
